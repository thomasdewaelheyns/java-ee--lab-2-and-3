package rental;

public class ReservationException extends Exception {

    public ReservationException(String string) {
        super(string);
    }
}